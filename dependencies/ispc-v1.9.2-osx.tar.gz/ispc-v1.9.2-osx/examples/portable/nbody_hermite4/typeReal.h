#pragma once
typedef double real;
