#pragma once
typedef float Key_t;
typedef int   Val_t;
